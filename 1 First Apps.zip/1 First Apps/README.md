# Readme

The homework will primaraly be assigned google codelabs. They will be organized into blocks/Lessons and each block may have several exercises (codelabs). 

Create a folder for each block and put the projects for that block in that folder. 




